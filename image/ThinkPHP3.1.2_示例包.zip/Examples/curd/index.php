<?php
//定义项目名称和路径
define('APP_NAME', 'curd');
define('APP_PATH', './');
// 开启调试模式
define('APP_DEBUG',TRUE);
// 加载框架入口文件
require( "../ThinkPHP/ThinkPHP.php");