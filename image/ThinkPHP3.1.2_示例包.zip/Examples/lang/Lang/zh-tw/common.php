<?php
return array(
	'welcome'=>'歡迎使用ThinkPHP',
	'remark'=>'您看到的是繁體中文',
);
?>