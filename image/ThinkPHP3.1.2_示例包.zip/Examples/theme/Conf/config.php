<?php
return array(
    'DEFAULT_THEME'  	=> 	'default',
    'THEME_LIST'		=>	'default,think',
    'TMPL_DETECT_THEME' => 	true, // 自动侦测模板主题
);